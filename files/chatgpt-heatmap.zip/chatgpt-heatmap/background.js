chrome.runtime.onInstalled.addListener(() => {
    console.log('ChatGPT Heatmap Extension installed');
});